import streamlit as st
from datetime import date, timedelta, datetime
from common import data, save_data, CATEGORIES, SKIN_TYPES, expiry_status, fmt_money, add_expense, page_header

page_header("🧴 화장품 보관함", "사용 중이거나 보관 중인 제품을 등록하고 찾아보세요.")
with st.expander("➕ 새 화장품 등록", expanded=not data["products"]):
    with st.form("add_product", clear_on_submit=True):
        name = st.text_input("제품명 *", placeholder="예: 수분 진정 크림")
        c1,c2 = st.columns(2)
        category = c1.selectbox("종류", CATEGORIES)
        skin_type = c2.selectbox("피부 타입", SKIN_TYPES)
        c3,c4 = st.columns(2)
        brand = c3.text_input("브랜드")
        price = c4.number_input("구매 가격(원)", min_value=0, step=1000)
        c5,c6 = st.columns(2)
        bought = c5.date_input("구매일", value=date.today())
        expiry = c6.date_input("유통기한", value=date.today()+timedelta(days=365))
        st.markdown("#### 📅 개봉일 및 개봉 후 사용기한")
        opened = st.checkbox("이 제품을 이미 개봉했어요")
        c7,c8 = st.columns(2)
        opened_date = c7.date_input("개봉일", value=date.today(), help="개봉하지 않았다면 체크를 해제해 주세요.")
        use_by_date = c8.date_input("개봉 후 사용기한 날짜", value=date.today()+timedelta(days=180), help="제품 용기에 표시된 개봉 후 사용 기간을 참고해 날짜를 설정하세요.")
        memo = st.text_area("메모", placeholder="사용감, 재구매 여부 등")
        submit = st.form_submit_button("보관함에 추가", use_container_width=True)
    if submit:
        if not name.strip():
            st.error("제품명을 입력해 주세요.")
        else:
            data["products"].append({"id":f"p{datetime.now().timestamp()}","name":name.strip(),"category":category,"skin_type":skin_type,"brand":brand.strip(),"price":int(price),"purchase_date":bought.isoformat(),"expiry_date":expiry.isoformat(),"opened":bool(opened),"opened_date":opened_date.isoformat() if opened else "","use_by_date":use_by_date.isoformat() if opened else "","memo":memo.strip()})
            if price > 0:
                add_expense(name.strip(), price, bought, category)
            save_data()
            st.success("제품을 등록했어요!")
            st.rerun()

if data["products"]:
    c1,c2,c3 = st.columns([2,1,1])
    search = c1.text_input("제품 검색", placeholder="제품명 또는 브랜드")
    cat = c2.selectbox("종류", ["전체"]+CATEGORIES)
    status_filter = c3.selectbox("유통기한", ["전체","기한 지남","내일 만료","임박","여유","날짜 미입력"])
    shown = [p for p in data["products"] if (not search or search.lower() in (p.get("name","")+" "+p.get("brand","")).lower()) and (cat=="전체" or p.get("category")==cat) and (status_filter=="전체" or expiry_status(p)[0]==status_filter)]
    st.caption(f"{len(shown)}개 제품")
    for p in shown:
        status, days = expiry_status(p)
        with st.container(border=True):
            left,right = st.columns([4,1])
            with left:
                st.markdown(f"### {p.get('name')}")
                st.caption(f"{p.get('brand') or '브랜드 미입력'} · {p.get('category')} · {p.get('skin_type')}")
                st.write(f"구매일: {p.get('purchase_date','-')} | 유통기한: {p.get('expiry_date','-')}")
                if p.get("opened"):
                    from common import opened_use_status
                    use_status, use_days = opened_use_status(p)
                    st.write(f"개봉일: {p.get('opened_date') or '-'} | 개봉 후 사용기한: {p.get('use_by_date') or '-'}")
                    if use_status == "내일 사용기한 종료":
                        st.warning("⚠️ 개봉 후 사용기한이 내일 끝나요.")
                    elif use_status == "사용기한 지남":
                        st.error("개봉 후 사용기한이 지났어요.")
                    elif use_status == "사용기한 임박":
                        st.warning(f"개봉 후 사용기한 임박 · {use_days}일 남음")
                else:
                    st.caption("아직 개봉하지 않은 제품")
                st.write(f"구매 가격: {fmt_money(p.get('price',0))}")
                if p.get("memo"): st.write(p["memo"])
            with right:
                if status=="기한 지남": st.error(status)
                elif status=="내일 만료": st.warning("⚠️ 내일 만료")
                elif status=="임박": st.warning(f"{status} ({days}일)")
                else: st.success(status)
                if st.button("삭제", key=f"del_{p['id']}"):
                    data["products"] = [x for x in data["products"] if x["id"] != p["id"]]
                    save_data()
                    st.rerun()
else:
    st.info("아직 등록한 제품이 없어요. 위에서 첫 화장품을 추가해 보세요.")
