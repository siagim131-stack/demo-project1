import streamlit as st
from datetime import date, datetime
from common import data, save_data, fmt_money, page_header

page_header("💗 위시리스트", "사고 싶은 화장품을 저장하고 구매 계획을 세워보세요.")

with st.expander("➕ 위시리스트에 추가", expanded=not data.get("wishlist", [])):
    with st.form("wishlist_add", clear_on_submit=True):
        name = st.text_input("제품명 *", placeholder="예: 수분 세럼")
        c1, c2 = st.columns(2)
        brand = c1.text_input("브랜드")
        price = c2.number_input("예상 가격(원)", min_value=0, step=1000, value=0)
        c3, c4 = st.columns(2)
        priority = c3.selectbox("구매 우선순위", ["높음", "보통", "낮음"])
        category = c4.selectbox("종류", ["스킨케어", "선케어", "메이크업", "클렌징", "바디케어", "헤어케어", "향수", "기타"])
        link = st.text_input("제품 링크(선택)", placeholder="https://...")
        memo = st.text_area("메모", placeholder="사고 싶은 이유, 색상, 용량 등")
        submit = st.form_submit_button("위시리스트에 추가", use_container_width=True)
    if submit:
        if not name.strip():
            st.error("제품명을 입력해 주세요.")
        else:
            data.setdefault("wishlist", []).append({
                "id": f"w{datetime.now().timestamp()}",
                "name": name.strip(), "brand": brand.strip(), "price": int(price),
                "priority": priority, "category": category, "link": link.strip(),
                "memo": memo.strip(), "added_date": date.today().isoformat(),
                "purchased": False
            })
            save_data()
            st.success("위시리스트에 추가했어요!")
            st.rerun()

wishlist = data.setdefault("wishlist", [])
if wishlist:
    pending = [x for x in wishlist if not x.get("purchased")]
    purchased = [x for x in wishlist if x.get("purchased")]
    a, b, c = st.columns(3)
    a.metric("전체", f"{len(wishlist)}개")
    b.metric("구매 예정", f"{len(pending)}개")
    c.metric("구매 완료", f"{len(purchased)}개")
    show = st.radio("목록 보기", ["구매 예정", "구매 완료", "전체"], horizontal=True)
    visible = pending if show == "구매 예정" else purchased if show == "구매 완료" else wishlist
    for item in sorted(visible, key=lambda x: ({"높음":0,"보통":1,"낮음":2}.get(x.get("priority"),1), x.get("added_date",""))):
        with st.container(border=True):
            left, right = st.columns([4,1])
            with left:
                st.markdown(f"### {item.get('name')}")
                st.caption(f"{item.get('brand') or '브랜드 미입력'} · {item.get('category','기타')} · 우선순위: {item.get('priority','보통')}")
                st.write(f"예상 가격: {fmt_money(item.get('price',0))}")
                if item.get("memo"):
                    st.write(item["memo"])
                if item.get("link","").startswith(("https://","http://")):
                    st.markdown(f"[제품 페이지 열기]({item['link']})")
            with right:
                if not item.get("purchased"):
                    if st.button("구매 완료", key=f"buy_{item['id']}", use_container_width=True):
                        item["purchased"] = True
                        item["purchased_date"] = date.today().isoformat()
                        save_data()
                        st.rerun()
                else:
                    st.success("구매 완료")
                    if st.button("예정으로 되돌리기", key=f"unbuy_{item['id']}", use_container_width=True):
                        item["purchased"] = False
                        save_data()
                        st.rerun()
                if st.button("삭제", key=f"delete_{item['id']}", use_container_width=True):
                    data["wishlist"] = [x for x in wishlist if x["id"] != item["id"]]
                    save_data()
                    st.rerun()
else:
    st.info("아직 위시리스트가 비어 있어요. 사고 싶은 화장품을 추가해 보세요.")
