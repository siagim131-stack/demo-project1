import streamlit as st
from datetime import date
from common import data, page_header, expiry_status, opened_use_status, fmt_money, ROUTINE_STEPS

page_header("🏠 홈 대시보드", "오늘의 화장품과 루틴, 소비 현황을 한눈에 확인해요.")
products = data["products"]
expiring = [p for p in products if expiry_status(p)[0] in ("기한 지남", "내일 만료", "임박")]
total_spend = sum(int(e.get("amount", 0)) for e in data["expenses"])
checks = data["routine_checks"].get(date.today().isoformat(), {})
total_steps = sum(len(v) for v in ROUTINE_STEPS.values())
done = sum(1 for v in checks.values() if v)
a,b,c,d = st.columns(4)
a.metric("보관 중인 제품", f"{len(products)}개")
b.metric("유통기한 확인 필요", f"{len(expiring)}개")
c.metric("오늘 루틴 완료", f"{done}/{total_steps}")
d.metric("누적 소비", fmt_money(total_spend))
st.divider()
left,right = st.columns(2)
with left:
    st.subheader("⏰ 유통기한 확인")
    if not expiring:
        st.success("확인이 필요한 제품이 없어요.")
    for p in sorted(expiring, key=lambda x:x.get("expiry_date") or "9999-12-31")[:6]:
        status, days = expiry_status(p)
        detail = f"{abs(days)}일 지남" if days is not None and days < 0 else f"{days}일 남음"
        if status == "내일 만료":
            st.warning(f"⚠️ **내일 유통기한 종료:** {p.get('name')} · {detail}")
        else:
            st.warning(f"**{p.get('name')}** · {status} · {detail}")
with right:
    st.subheader("✨ 오늘 루틴")
    if done == total_steps:
        st.success("오늘 루틴을 모두 완료했어요!")
    else:
        st.info(f"오늘 {total_steps-done}개 단계가 남아 있어요.")
    st.page_link("pages/4_루틴_체크.py", label="루틴 체크로 이동 →")
use_tomorrow = [p for p in products if opened_use_status(p)[0] == "내일 사용기한 종료"]
if use_tomorrow:
    st.subheader("⚠️ 개봉 후 사용기한 하루 전")
    for p in use_tomorrow:
        st.warning(f"**{p.get('name')}**의 개봉 후 사용기한이 내일 끝나요.")

st.subheader("최근 소비 기록")
recent = sorted(data["expenses"], key=lambda x:x.get("date",""), reverse=True)[:5]
if recent:
    for e in recent:
        st.write(f"**{e.get('name')}** · {e.get('date')} · {fmt_money(e.get('amount',0))}")
else:
    st.caption("아직 소비 기록이 없어요.")
