import streamlit as st
from datetime import date, timedelta
from common import data, save_data, ROUTINE_STEPS, page_header

page_header("✨ 루틴 체크", "날짜별로 아침·저녁 스킨케어 루틴을 체크해요.")
selected = st.date_input("체크할 날짜", value=date.today())
day_key = selected.isoformat()
checks = data["routine_checks"].get(day_key,{})
left,right=st.columns(2)
for col, period in [(left,"아침"),(right,"저녁")]:
    with col:
        with st.container(border=True):
            st.subheader(("☀️ " if period=="아침" else "🌙 ")+period+" 루틴")
            for step in ROUTINE_STEPS[period]:
                key=f"{period}_{step}"
                checks[key]=st.checkbox(step,value=bool(checks.get(key,False)),key=f"{day_key}_{key}")
            done=sum(bool(checks.get(f"{period}_{step}",False)) for step in ROUTINE_STEPS[period])
            st.progress(done/len(ROUTINE_STEPS[period]))
            st.caption(f"{done}/{len(ROUTINE_STEPS[period])} 단계 완료")
if st.button("루틴 기록 저장",type="primary",use_container_width=True):
    data["routine_checks"][day_key]=checks
    save_data()
    st.success("루틴 기록을 저장했어요.")
st.subheader("📅 최근 7일 완료율")
days=[selected-timedelta(days=i) for i in range(6,-1,-1)]
labels=[]; values=[]
for d in days:
    daily=data["routine_checks"].get(d.isoformat(),{})
    labels.append(d.strftime("%m/%d"))
    values.append(sum(1 for v in daily.values() if v)/sum(len(v) for v in ROUTINE_STEPS.values()))
st.bar_chart({"날짜":labels,"완료율":values},x="날짜",y="완료율")
