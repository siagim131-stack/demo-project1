import streamlit as st
from common import data, page_header, expiry_status, opened_use_status

page_header("⏰ 유통기한 관리", "기한이 지난 제품과 30일 이내에 기한이 다가오는 제품을 확인해요.")
if not data["products"]:
    st.info("화장품 보관함에 제품을 먼저 등록해 주세요.")
else:
    expired=[p for p in data["products"] if expiry_status(p)[0]=="기한 지남"]
    tomorrow=[p for p in data["products"] if expiry_status(p)[0]=="내일 만료"]
    soon=[p for p in data["products"] if expiry_status(p)[0]=="임박"]
    ok=[p for p in data["products"] if expiry_status(p)[0]=="여유"]
    a,b,c,d=st.columns(4)
    a.metric("기한 지남",len(expired)); b.metric("내일 만료",len(tomorrow)); c.metric("30일 이내 임박",len(soon)); d.metric("여유 있음",len(ok))
    for title, group in [("🚨 유통기한이 지난 제품",expired),("⚠️ 내일 유통기한이 끝나는 제품",tomorrow),("📅 30일 이내 임박 제품",soon),("🌿 아직 여유 있는 제품",ok)]:
        st.subheader(title)
        if not group: st.caption("해당하는 제품이 없어요.")
        for p in sorted(group,key=lambda x:x.get("expiry_date") or ""):
            status,days=expiry_status(p)
            detail=f"{abs(days)}일 지남" if days is not None and days<0 else f"{days}일 남음"
            with st.container(border=True):
                if status == "내일 만료":
                    st.warning(f"⚠️ **내일 유통기한 종료:** {p.get('name')} · {p.get('brand') or '브랜드 미입력'}")
                else:
                    st.markdown(f"**{p.get('name')}** · {p.get('brand') or '브랜드 미입력'}")
                st.write(f"유통기한: {p.get('expiry_date')} · {detail}")


st.divider()
st.subheader("🧴 개봉 후 사용기한")
opened_products = [p for p in data["products"] if p.get("opened") and p.get("use_by_date")]
if not opened_products:
    st.caption("개봉일과 개봉 후 사용기한을 등록한 제품이 없어요.")
else:
    for p in sorted(opened_products, key=lambda x: x.get("use_by_date", "")):
        status, days = opened_use_status(p)
        detail = f"{abs(days)}일 지남" if days is not None and days < 0 else (f"{days}일 남음" if days is not None else "")
        with st.container(border=True):
            if status == "내일 사용기한 종료":
                st.warning(f"⚠️ **개봉 후 사용기한이 내일 끝나요:** {p.get('name')}")
            elif status == "사용기한 지남":
                st.error(f"**개봉 후 사용기한 지남:** {p.get('name')}")
            elif status == "사용기한 임박":
                st.warning(f"**개봉 후 사용기한 임박:** {p.get('name')}")
            else:
                st.markdown(f"**{p.get('name')}**")
            st.write(f"개봉일: {p.get('opened_date', '-')} · 사용기한: {p.get('use_by_date', '-')} · {detail}")
