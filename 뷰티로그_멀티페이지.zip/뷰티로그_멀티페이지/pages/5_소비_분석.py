import streamlit as st
from datetime import date
from common import data, save_data, CATEGORIES, add_expense, fmt_money, page_header

page_header("💸 소비 분석", "화장품 구매 비용을 기록하고 카테고리별 지출을 확인해요.")
with st.expander("➕ 구매 내역 추가",expanded=not data["expenses"]):
    with st.form("add_expense",clear_on_submit=True):
        name=st.text_input("구매 제품명 *")
        a,b=st.columns(2)
        amount=a.number_input("금액(원) *",min_value=0,step=1000)
        bought=b.date_input("구매일",value=date.today())
        category=st.selectbox("종류",CATEGORIES)
        submit=st.form_submit_button("소비 기록 추가",use_container_width=True)
    if submit:
        if not name.strip(): st.error("제품명을 입력해 주세요.")
        elif amount<=0: st.error("금액을 1원 이상 입력해 주세요.")
        else:
            add_expense(name.strip(),amount,bought,category); save_data(); st.success("소비 기록을 추가했어요."); st.rerun()
if data["expenses"]:
    expenses=data["expenses"]
    total=sum(int(e.get("amount",0)) for e in expenses)
    month=date.today().strftime("%Y-%m")
    month_total=sum(int(e.get("amount",0)) for e in expenses if str(e.get("date","")).startswith(month))
    a,b,c=st.columns(3)
    a.metric("누적 소비",fmt_money(total)); b.metric("이번 달 소비",fmt_money(month_total)); c.metric("구매 기록 수",f"{len(expenses)}건")
    by_cat={}
    for e in expenses: by_cat[e.get("category","기타")]=by_cat.get(e.get("category","기타"),0)+int(e.get("amount",0))
    st.subheader("카테고리별 소비"); st.bar_chart(by_cat)
    st.subheader("구매 내역")
    for e in sorted(expenses,key=lambda x:x.get("date",""),reverse=True):
        with st.container(border=True):
            a,b=st.columns([4,1])
            with a:
                st.markdown(f"**{e.get('name')}**")
                st.caption(f"{e.get('date')} · {e.get('category','기타')}")
                st.write(fmt_money(e.get("amount",0)))
            with b:
                if st.button("삭제",key=f"del_{e['id']}"):
                    data["expenses"]=[x for x in data["expenses"] if x["id"]!=e["id"]]
                    save_data(); st.rerun()
else: st.info("아직 소비 기록이 없어요. 위에서 첫 구매 내역을 추가해 보세요.")
